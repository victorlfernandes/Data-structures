#include "treap.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>

struct node {
    element_t value;
    int priority;
    node_t *left_child;
    node_t *right_child;
};

node_t *create_node(element_t value, int priority) {

    node_t *new_node = malloc(sizeof(node_t));
    assert(new_node != NULL);

    new_node->value = value;
    new_node->priority = priority;
    new_node->left_child = NULL;
    new_node->right_child = NULL;

    return new_node;
}

tree_t *create_tree() {

    tree_t *tree = malloc(sizeof(tree_t));
    assert(tree != NULL);

    tree->root = NULL;
 
    return tree;
}

void delete_nodes(node_t *node) {

    if (node != NULL) {
        delete_nodes(node->left_child);
        delete_nodes(node->right_child);
        free(node);
    }

}

void delete_tree(tree_t *tree) {

    assert(tree != NULL);

    delete_nodes(tree->root);

    free(tree);
}

node_t *insert_node(node_t **node, element_t value, int priority) {

    // using double pointer because the address is gonna be changed
    // by the function (when assigning with malloc)
    
    if (*node == NULL) { 
        // found leaf node to insert
        *node = create_node(value, priority);
        return *node;
    }

    if (value == (*node)->value)
        // cannot insert repeated element
        return NULL;

    if (value < (*node)->value) {
        (*node)->left_child = insert_node(&(*node)->left_child, value, priority);
        if ((*node)->left_child->priority > (*node)->priority)
            (*node) = right_rotate(*node);
    }

    else {
        (*node)->right_child = insert_node(&(*node)->right_child, value, priority);
        if ((*node)->right_child->priority > (*node)->priority)
            (*node) = left_rotate(*node);
    }

    return *node;
}

void tree_insert(tree_t *tree, element_t value, int priority) {

    assert(tree != NULL);

    if (tree_search(tree, value)) {
        printf("Elemento ja existente\n");
        return;
    }

    insert_node(&tree->root, value, priority);    
}

node_t *remove_node(node_t **node, element_t value) {

    if (*node == NULL)
        return *node;

    else if (value < (*node)->value)
        (*node)->left_child = remove_node(&(*node)->left_child, value);

    else if (value > (*node)->value)
        (*node)->right_child = remove_node(&(*node)->right_child, value);

    else {

        // if ((*node)->left_child == NULL && (*node)->right_child == NULL) {
        //     node_t *aux = *node;
        //     *node = (*node)->right_child;
        //     free(aux);
        // }

        // else if ((*node)->left_child->priority < (*node)->right_child->priority) {
        //     (*node)->priority -= INT_MAX;
        //     *node = left_rotate(*node);
        //     (*node)->left_child = remove_node(&(*node)->left_child, value);
        // }

        if ((*node)->left_child == NULL) {
            node_t *aux = *node;
            *node = (*node)->right_child;
            free(aux);
        }

        else if ((*node)->right_child == NULL) {
            node_t *aux = *node;
            *node = (*node)->left_child;
            free(aux);
        }

        else {
            *node = left_rotate(*node);
            (*node)->left_child = remove_node(&(*node)->left_child, value);
        }

        // else if ((*node)->left_child->priority < (*node)->right_child->priority) {
        //     *node = left_rotate(*node);
        //     (*node)->left_child = remove_node(&(*node)->left_child, value);
        // }

        // else {
        //     *node = right_rotate(*node);
        //     (*node)->right_child = remove_node(&(*node)->right_child, value);
        // }
    }

    return *node;
}

void tree_removal(tree_t *tree, element_t value) {

    assert(tree != NULL);

    if (!tree_search(tree, value)) {
        printf("Chave nao localizada\n");
        return;
    }

    remove_node(&tree->root, value);
}

node_t *search_node(node_t *node, element_t key) {

    if (node == NULL)
        return NULL;
    
    if (node->value == key)
        return node;

    if (key < node->value)
        return search_node(node->left_child, key);

    return search_node(node->right_child, key);
}

bool tree_search(tree_t *tree, element_t key) {

    assert(tree != NULL);

    node_t *aux = search_node(tree->root, key);

    if (aux == NULL)
        return false;
    else
        return true;
}

void print_node(node_t *node) {

    printf("(%d, %d) ", node->value, node->priority);

}

void print_tree(tree_t *tree, node_t *root) {

    if (root != NULL) {
        print_node(root);
        printf(" (");
        print_tree(tree, root->left_child);
        printf(", ");
        print_tree(tree, root->right_child);
        printf(")");
    }
    else
        printf("null");

    if (root == tree->root)
        printf("\n");
}

void print_preorder(node_t *root) {

    if (root == NULL)
        return;

    print_node(root);
    print_preorder(root->left_child); 
    print_preorder(root->right_child); 
}

void print_inorder(node_t *root) {

    if (root == NULL)
        return;

    print_inorder(root->left_child); 
    print_node(root);
    print_inorder(root->right_child); 
}

void print_postorder(node_t *root) {

    if (root == NULL)
        return;

    print_postorder(root->left_child); 
    print_postorder(root->right_child); 
    print_node(root);
}

void print_level(node_t *root, int level) {

    if (root == NULL)
        return;

    if (level == 1)
        print_node(root);
    else if (level > 1) {
        print_level(root->left_child, level - 1);
        print_level(root->right_child, level - 1);
    }
}

void print_in_width(node_t *root) {

    int height = tree_height(root);

    for (int i = 1; i <= height; i++) 
        print_level(root, i);
}

int tree_height(node_t *root) {

    if (root == NULL)
        return 0;

    int left_height = 1 + tree_height(root->left_child);
    int right_height = 1 + tree_height(root->right_child);

    return (left_height > right_height) ? left_height : right_height;
}

node_t *left_rotate(node_t *unbalanced) {

    node_t *aux = unbalanced->right_child;
    unbalanced->right_child = aux->left_child;
    aux->left_child = unbalanced;

    return aux;
}

node_t *right_rotate(node_t *unbalanced) {

    node_t *aux = unbalanced->left_child;
    unbalanced->left_child = aux->right_child;
    aux->right_child = unbalanced;

    return aux;
}
